BUNDLE DO PILOTO DE INFERÊNCIA PH² x HAM10000  (branch exp/dataset_validation)

1) Descompacte em uma pasta e instale: pip install -r requirements.txt
   (precisa de torch/torchvision, langchain-openai, langchain-google-genai, langgraph, scipy, Pillow, pyyaml)
2) export OPENAI_API_KEY=...  e  GOOGLE_API_KEY=...
3) Edite LOCAL_PATHS no topo de scripts/run_inference_pilot.py (ou use flags):
   ph2_dir, ph2_metadata_txt, ham_image_dir, ham_metadata_csv, ham_mask_dir OU ham_mask_zip
4) python scripts/run_inference_pilot.py --dry-run     (valida sem custo)
   python scripts/run_inference_pilot.py               (640 chamadas; retoma se interromper)
5) Traga de volta experiments/dataset_validation/pilot_inference_outputs_*.zip
